# Alphi Parlour

Full-stack nail parlour booking platform.

## Getting Started

Follow the instructions in the main guide to set up backend and frontend.
